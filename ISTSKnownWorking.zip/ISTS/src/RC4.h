#pragma once

#include <Windows.h>

typedef struct
{
	unsigned int i;
	unsigned int j;
	unsigned char s[256];

} Rc4Context;

void rc4Init(Rc4Context* context, const unsigned char* key, size_t length);
void rc4Cipher(Rc4Context* context, const unsigned char* input, unsigned char* output, size_t length);
void RC4Crypt(unsigned char* key, unsigned char* input, unsigned char* output, size_t size);
